let input = require('fs').readFileSync('./dev/stdin/file.txt', 'utf8')
let = lines = input.split('\n')

let palavra = lines.shift()
switch (palavra.lenght) {
    case "brasil":
        console.log ("Feliz Natal!")
    break
    case "portugal":
        console.log ("Feliz Natal!")
    break
    case "alemanha":
        console.log ("Frohliche Weihnachten!")
    break
    case "austria":
        console.log ("Frohe Weihnacht!")
    break
    case "coreia":
        console.log ("Chuk Sung Tan!")
    break
    case "espanha":
        console.log ("Feliz Navidad!")
    break
    case "argentina":
        console.log ("Feliz Navidad!")
    break
    case "chile":
        console.log ("Feliz Navidad!")
    break
    case "mexico":
        console.log ("Feliz Navidad!")
    break
    case "grecia":
        console.log ("Kala Christougena!")
    break
    case "estados-unidos":
        console.log ("Merry Christmas!")
    break
    case "inglaterra":
        console.log ("Merry Christmas!")
    break
    case "australia":
        console.log ("Merry Christmas!")
    break
    case "antartida":
        console.log ("Merry Christmas!")
    break
    case "canada":
        console.log ("Merry Christmas!")
    break
    case "suecia":
        console.log ("God Jul!")
    break
    case "turquia":
        console.log ("Mutlu Noell2er")
    break
    case "irlanda":
        console.log ("Nollaig Shona Dhuit!")
    break
    case "belgica":
        console.log ("Zalig Kerstfeest!")
    break
    case "italia":
        console.log ("Buon Natale!")
    break
    case "libia":
        console.log ("Buon Natale!")
    break
    case "siria":
        console.log ("Milad Mubarak!")
    break
    case "marrocos": 
        console.log ("Milad Mubarak!")
    break
    case "japao":
        console.log ("Merii Kurisumasu!")
    break
    default:
    console.log ("--- NOT FOUND ---")
}



