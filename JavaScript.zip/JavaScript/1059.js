for (let cont=0; cont<100; cont+2){
    cont+=2
    console.log(cont)
}